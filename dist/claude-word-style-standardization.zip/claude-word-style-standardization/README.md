# word-style-standardization Claude Skill

Word 标准样式规整skill。这个 Skill 可以清理源 Word 文件中混乱、多余的样式，将标题、正文、表格、图片、列表等内容统一套用标准 Word 模板样式。处理后会生成一个新的规整版 Word 文件，后续只需在 Word 中对样式做一次点击/刷新，即可得到整体格式统一、对象关系完整的标准化文档。

这个 Claude Skill 用于将 `.docx` 文件按标准 Word 模板进行原位样式规整。

重点原则：

- 不抽取文本重建 Word。
- 保留源 `.docx` 包结构、图片、表格、页眉页脚、对象锚点、媒体引用和嵌入对象。
- 只把源文档已有 heading 1-9 语义的段落映射为模板标题样式。
- 正文中的 `一、二、三`、`1、2、3`、`1）、2）、3）` 保留为手工编号文本，不套模板编号样式。
- 正文自动编号会先转成段首手工编号文本，再移除 `w:numPr`。
- 只有文本自带明确项目符号或自动编号定义为 bullet 时才套箭头/打钩/四角星列表样式；数字编号不会误套箭头，避免出现“箭头 + 1)”的重复编号。
- 表格本体会套用模板中的“表格标准样式”，表格内段落会套用 `P_普通图表标准格式_表格`。
- 清理会覆盖模板样式的直接格式：表格单元格边框/底纹、标题直接格式、正文基础字体字号颜色和段落间距缩进。
- 表格统一设置为 100% 页面宽度，清理源文档列宽和固定布局约束，让 Word 在页宽内重新自动分配列宽。
- 输出规整后的 `.docx` 和校验报告。

## 目录

```text
claude-word-style-standardization/
├── SKILL.md
├── README.md
├── requirements.txt
├── scripts/
│   └── normalize_word_style.py
├── references/
│   └── checklist.md
└── assets/
    └── 标准样式Word文档.docx
```

## 使用

```bash
python -m venv .venv
.venv/bin/pip install -r requirements.txt
mkdir -p input output
.venv/bin/python scripts/normalize_word_style.py \
  --input input/source.docx \
  --template assets/标准样式Word文档.docx
```

默认输出到 `output/<源文件名>_标准样式规整.docx`，校验报告输出到 `output/<源文件名>_样式规整校验报告.md`。如需自定义路径，可显式传入 `--output` 和 `--report`。

## 给使用者的提示词

请使用 `word-style-standardization` 技能，将 `input/source.docx` 按 `assets/标准样式Word文档.docx` 进行样式规整。要求采用原位处理方式，不要重建正文；保留图片、表格、页眉页脚、对象锚点、媒体引用和嵌入对象；不要凭文本推断标题；正文自动编号转为手工编号；生成规整后的 docx，并输出校验报告。
